package main;

public class Clinicmain {
	public static void main(String[] args) {
		System.out.println("**********Welcome to Hivrale Clinic ***********");
        MainMenu menu = new MainMenu();
        menu.login();
        menu.mainMenu();
    }

}
