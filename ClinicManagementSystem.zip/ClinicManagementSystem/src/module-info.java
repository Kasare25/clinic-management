/**
 * 
 */
/**
 * 
 */
module ClinicManagementSystem {
	requires java.sql;
}