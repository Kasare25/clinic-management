package menu;

import java.util.Scanner;

import Operation.AppointmentOperation;
import Operation.DiseaseOperation;
import Operation.DoctorOperation;
import Operation.MedicalRecordOperation;
import Operation.PatientOperation;


public class AdminMenu {

	public static void adminMenu(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\nWelcome to Admin Page\n");
	           System.out.println("Press 1 for Disease operations");
	           System.out.println("Press 2 for Doctor operations");
	           System.out.println("Press 3 for Patient operations");
	           System.out.println("Press 4 for Appointment operations");
	           System.out.println("Press 5 for MedicalRecord operations");
	           System.out.println("Press 0 to Logout from Admin menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           switch (choice) {
	               case 1:
	                   manageDiseases(sc);
	                   break;
	               case 2:
	                   manageDoctors(sc);
	                   break;
	               case 3:
	                   managePatient(sc);
	                   break;
	               case 4:
	                   manageAppointments(sc);
	                   break;
	               case 5:
	                   manageMedicalRecords(sc);
	                   break;
	               case 0:
	                   System.out.println("Logged out successfully from Admin page.");
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }

	   public static void manageDiseases(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\nWelcome to Disease operation\n");
	           System.out.println("Press 1 to Add a Diseases");
	           System.out.println("Press 2 to Update a Diseases");
	           System.out.println("Press 3 to View all Diseases");
	           System.out.println("Press 4 to View Disease by Id");
	           System.out.println("Press 5 to Delete Disease by Id");
	           System.out.println("Press 0 for returning to admin menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           switch (choice) {
	               case 1:
	            	   DiseaseOperation.addDisease(sc);
	                   break;
	               case 2:
	            	   DiseaseOperation.updateDisease(sc);
	                   break;
	               case 3:
	            	   DiseaseOperation.showDiseases(sc);
	                   break;
	               case 4:
	            	   DiseaseOperation.showDiseaseById(sc);
	                   break;
	               case 5:
	            	   DiseaseOperation.deleteDiseaseById(sc);
	                   break;
	               case 0:
	                   System.out.println("Returning back to admin menu.");
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }

	   public static void manageDoctors(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\nWelcome to Doctor operation\n");
	           System.out.println("Press 1 to Add an Doctor");
	           System.out.println("Press 2 to Update an Doctor");
	           System.out.println("Press 3 to View all Doctors");
	           System.out.println("Press 4 to View Doctor by Id");
	           System.out.println("Press 5 to Delete Doctor by Id");
	           System.out.println("Press 0 for returning to admin menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           switch (choice) {
	               case 1:
	            	   DoctorOperation.addDoctor(sc);
	                   break;
	               case 2:
	            	   DoctorOperation.updateDoctor(sc);
	                   break;
	               case 3:
	            	   DoctorOperation.showDoctors(sc);
	                   break;
	               case 4:
	            	   DoctorOperation.showDoctorById(sc);
	                   break;
	               case 5:
	            	   DoctorOperation.deleteDoctorById(sc);
	                   break;
	               case 0:
	                   System.out.println("Returning back to admin menu.");
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }

	   public static void manageAppointments(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\nWelcome to Appointment operation\n");
	           System.out.println("Press 1 to Add an Appointment");
	           System.out.println("Press 2 to Update an Appointment");
	           System.out.println("Press 3 to View all Appointments");
	           System.out.println("Press 4 to View Appointmentby Id");
	           System.out.println("Press 5 to Delete Appointment by Id");
	           System.out.println("Press 0 for returning to admin menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           switch (choice) {
	               case 1:
	            	   AppointmentOperation.addAppointment(sc);
	                   break;
	               case 2:
	            	   AppointmentOperation.updateAppointment(sc);
	                   break;
	               case 3:
	            	   AppointmentOperation.showAppointments(sc);
	                   break;
	               case 4:
	            	   AppointmentOperation.showAppointmentById(sc);
	                   break;
	               case 5:
	            	   AppointmentOperation.deleteAppointmentById(sc);
	                   break;
	               case 0:
	                   System.out.println("Returning back to admin menu.");
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }

	   public static void manageMedicalRecords(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\nWelcome to MedicalRecord operation\n");
	           System.out.println("Press 1 to Add a MedicalRecord");
	           System.out.println("Press 2 to Update a MedicalRecord");
	           System.out.println("Press 3 to View all MedicalRecords");
	           System.out.println("Press 4 to View MedicalRecord by Id");
	           System.out.println("Press 5 to Delete MedicalRecord by Id");
	           System.out.println("Press 0 for returning to admin menu");

	           System.out.print("\nEnter your choice:");
	           choice = sc.nextInt();
	           switch (choice) {
	               case 1:
	            	   MedicalRecordOperation.addMedicalRecord(sc);
	                   break;
	               case 2:
	            	   MedicalRecordOperation.updateMedicalRecord(sc);
	                   break;
	               case 3:
	            	   MedicalRecordOperation.showMedicalRecords(sc);
	                   break;
	               case 4:
	            	   MedicalRecordOperation.showMedicalRecordById(sc);
	                   break;
	               case 5:
	            	   MedicalRecordOperation.deleteMedicalRecordById(sc);
	                   break;
	               case 0:
	                   System.out.println("Returning back to admin menu.");
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }

	   public static void managePatient(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\nWelcome to Patient operation\n");
	           System.out.println("Press 1 to Add a Patient");
	           System.out.println("Press 2 to Update a Patient");
	           System.out.println("Press 3 to View all Patients");
	           System.out.println("Press 4 to View Patient by Id");
	           System.out.println("Press 5 to Delete Patient by Id");
	           System.out.println("Press 0 for returning to admin menu");

	           System.out.print("\nEnter your choice:");
	           choice = sc.nextInt();
	           switch (choice) {
	               case 1:
	            	   PatientOperation.addPatient(sc);
	                   break;
	               case 2:
                 	   PatientOperation.updatePatient(sc);
	                   break;
	               case 3:
	            	   PatientOperation.showPatients(sc);
	                   break;
	               case 4:
	            	   PatientOperation.showPatientById(sc);
	                   break;
	               case 5:
                 	   PatientOperation.deletePatientById(sc);
	                   break;
	               case 0:
	                   System.out.println("Returning back to admin menu.");
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }
}


