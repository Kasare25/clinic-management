package menu;

import java.util.Scanner;

import Operation.DiseaseOperation;
import Operation.DoctorOperation;
import Operation.MedicalRecordOperation;
import Operation.PatientOperation;

public class PatientMenu {

	public static void patientMenu(Scanner sc) {
		int choice;
        do {
            System.out.println("Patients Menu");
            System.out.println("1. View Doctors");
            System.out.println("2. View Diseases");
            System.out.println("3. View Patient By Id");
            System.out.println("4. View MedicalRecord");
            System.out.println("0. Logout");


            choice = sc.nextInt();
            switch (choice) {
            	case 1:
	            	processDoctor(sc);
	                break;    
            	case 2:
            		processDisease(sc);
                    break;
                case 3:
                	PatientOperation.showPatientById(sc);
                    break;
                case 4:
                	MedicalRecordOperation.showMedicalRecordById(sc);
                    break;
                case 6:
                    break;
                case 0:
                    System.out.println("Logged out.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

	private static void processDisease(Scanner sc) {
		int choice;
        do {
            System.out.println("Welcome to Disease operation");
            System.out.println("1. View Disease By Id");
            System.out.println("2. View all Diseases");
            System.out.println("0. Back");

            choice = sc.nextInt();
            switch (choice) {
                case 1:
                	DiseaseOperation.showDiseaseById(sc);
                    break;
                case 2:
                	DiseaseOperation.showDiseases(sc);
                    break;
                case 0:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

	private static void processDoctor(Scanner sc) {
		 int choice;
	        do {
	            System.out.println("Welcome to Doctor operation");
	            System.out.println("1. View Doctor By Id");
	            System.out.println("2. View Doctors");
	            System.out.println("0. Back");

	            choice = sc.nextInt();
	            switch (choice) {
	                case 1:
	                    DoctorOperation.showDoctorById(sc);
	                    break;
	                case 2:
	                	DoctorOperation.showDoctors(sc);
	                    break;
	                case 0:
	                    System.out.println("Returning to main menu...");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        } while (choice != 0);

		
	}
    

		
	

}
