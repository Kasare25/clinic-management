package menu;

import java.util.Scanner;

import Operation.AppointmentOperation;
import Operation.DiseaseOperation;
import Operation.DoctorOperation;
import Operation.MedicalRecordOperation;
import Operation.PatientOperation;

public class DoctorMenu {

	public static void doctorMenu(Scanner sc) {
		int choice;
        do {
            System.out.println("\nWelcome to Doctor Page\n");
            System.out.println("Press 1 to process Doctors");
            System.out.println("Press 2 to process Diseases");
            System.out.println("Press 3 to process Patients");
            System.out.println("Press 4 to process Appointments");
            System.out.println("Press 5 to process  MedicalRecords");
            System.out.println("Press 0 to Logout from Doctor menu");

            System.out.print("\nEnter your choice: ");
            choice = sc.nextInt();
            switch (choice) {
            	case 1:
	            	processDoctor(sc);
	                break;    
            	case 2:
            		processDisease(sc);
                    break;
                case 3:
                	processPatient(sc);
                    break;
                case 4:
                	processAppointment(sc);
                    break;
                case 5:
                	processMedicalRecord(sc);
                    break;
                case 7:
                    break;
                case 0:
                    System.out.println("Logged out.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

	private static void processMedicalRecord(Scanner sc) {
		int choice;
        do {
            System.out.println("\nWelcome to MedicalRecord operation\n");
            System.out.println("Press 1 to MedicalRecord Patients");
            System.out.println("Press 2 to View MedicalRecord By PatientId");
            System.out.println("Press 3 to View MedicalRecord By CourseId");
            System.out.println("Press 0 for returning to Doctor menu");

            System.out.print("\nEnter your choice: ");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                	MedicalRecordOperation.addMedicalRecordByPatientId(sc);
                    break;
                case 2:
                	MedicalRecordOperation.showMedicalRecordById(sc);
                    break;
                case 3:
                	MedicalRecordOperation.showMedicalRecords(sc);
                    break;
                case 0:
                    System.out.println("Returning back to Doctor menu.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

		
	}

	private static void processAppointment(Scanner sc) {
		 int choice;
	        do {
	            System.out.println("\nWelcome to Appointment operation\n");
	            System.out.println("Press 1 to View Appointed Patient By AppointmentId");
	            System.out.println("Press 2 to View Appointed Patient By PatientId");
	        	System.out.println("Press 3 to View Appointed Patients");
	            System.out.println("Press 0 for returning to doctor menu");

	            System.out.print("\nEnter your choice: ");
	            choice = sc.nextInt();
	            switch (choice) {
	                case 1:
	                	AppointmentOperation.showAppointmentById(sc);
	                    break;
	                case 2:
	                	AppointmentOperation.showAppointmentByPatientId(sc);
	                    break;
	                case 3:
	                	AppointmentOperation.showAppointments(sc);
	                    break;
	                case 0:
	                    System.out.println("Returning back to instructor menu.");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        } while (choice != 0);

		
	}

	private static void processPatient(Scanner sc) {
		  int choice;
	        do {
	            System.out.println("\nWelcome to Patient operation\n");
	            System.out.println("Press 1 to View Patient By Id");
	            System.out.println("Press 2 to View all Patients");
	            System.out.println("Press 0 for returning to Doctor menu");

	            System.out.print("\nEnter your choice: ");
	            choice = sc.nextInt();
	            switch (choice) {
	                case 1:
	                	PatientOperation.showPatientById(sc);
	                    break;
	                case 2:
	                	PatientOperation.showPatients(sc);
	                    break;
	                case 0:
	                    System.out.println("Returning back to Doctor menu.");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        } while (choice != 0);

		
	}

	private static void processDisease(Scanner sc) {
		int choice;
        do {
            System.out.println("\nWelcome to Disease operation\n");
            System.out.println("Press 1 to View Disease By Id");
            System.out.println("Press 2 to View all Diseases");
            System.out.println("Press 0 for returning to Doctor menu");

            System.out.print("\nEnter your choice: ");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                	DiseaseOperation.showDiseaseById(sc);
                    break;
                case 2:
                	DiseaseOperation.showDiseases(sc);
                    break;
                case 0:
                    System.out.println("Returning back to instructor menu.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);


		
	}

	private static void processDoctor(Scanner sc) {
		int choice;
        do {
            System.out.println("\nWelcome to Doctor operation\n");
            System.out.println("Press 1 to View Doctor By Id");
            System.out.println("Press 2 to View Assigned Diseases By DiseaseId");
            System.out.println("Press 3 to View Doctors");
            System.out.println("Press 0 for returning to Doctors menu");

            System.out.print("\nEnter your choice: ");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                	DoctorOperation.showDoctorById(sc);
                    break;
                case 2:
                	DoctorOperation.showAssignedDiseases(sc);
                    break;
                case 3:
                	DoctorOperation.showDoctors(sc);
                    break;
                case 0:
                    System.out.println("Returning back to Doctor menu.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
		
	}
 }
