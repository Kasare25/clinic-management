package model;

import java.sql.Date;

public class Patient {

	
}
