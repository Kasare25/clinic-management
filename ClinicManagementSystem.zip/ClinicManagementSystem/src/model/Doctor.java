package model;

public class Doctor {

	private String DoctorID; 
	private String DoctorName; 
	private String Email;
	private String DoctorContact ;

	 public Doctor(String DoctorID, String DoctorName, String Email, String DoctorContact) {
	        this.DoctorID = DoctorID;
	        this.DoctorName = DoctorName;
	        this.Email = Email;
	        this.DoctorContact = DoctorContact;
	    }

	 
		public Doctor() {
		// TODO Auto-generated constructor stub
	}

		// Getters and setters
	    public String getDoctorID() {
	        return DoctorID;
	    }

	    

	    public String getEmail() {
	        return Email;
	    }

	    public void setEmail(String Email) {
	        this.Email = Email;
	    }

	    public String getDoctorName() {
	        return DoctorName;
	    }

	    public void setDoctorName(String DoctorName) {
	        this.DoctorName = DoctorName;
	    }

	    public String getDoctorContact() {
	        return DoctorContact;
	    }

	    public void setDoctorContact(String DoctorContact) {
	        this.DoctorContact = DoctorContact;
	    }

	    @Override
	    public String toString() {
	        return "Dctor{" +
	                "DoctorID='" + DoctorID + '\'' +
	                ", Email='" + Email + '\'' +
	                ", DoctorName='" + DoctorName + '\'' +
	                ", DoctorContact='" + DoctorContact + '\'' +
	                '}';
	    }


		public void add(Doctor doctor) {
			// TODO Auto-generated method stub
			
		}


		public void setDoctorID(String string) {
			 this.DoctorID = DoctorID;
			
		}


}
