package Operation;

import java.util.Scanner;

public class DiseaseOperation {

	public static void addDisease(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void updateDisease(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void showDiseases(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void showDiseaseById(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void deleteDiseaseById(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

}
