package Operation;

import java.util.Scanner;


import Dao.PatientDAO;
import model.Patient;


public class PatientOperation {
	
	     public static  void addPatient(Scanner sc) {
		 System.out.println("Enter Patient ID:");
	        String PatientID = sc.next();

	        System.out.println("Enter PatientName:");
	        String PatientName = sc.nextLine();
	        sc.nextLine();

	        System.out.println("Enter date of birth (YYYY-MM-DD):");
	        String DateOfBirth = sc.next();
	        
	        System.out.println("Enter Address:");
	        String Address = sc.next();

            System.out.println("Enter email:");
	        String Email = sc.next();

	        System.out.println("Enter PatientDisease:");
	        String PatientDisease = sc.next();

	        

	        // Creating object of Patient class
	        Patient obj = new Patient(PatientID,PatientName, java.sql.Date.valueOf(DateOfBirth), Address, Email, PatientDisease);

	        // Calling method to insert into table and passing the object of Student class
	        boolean result = PatientDAO.insert(obj);
	        if (result) {
	            System.out.println("The Patients is successfully added.");
	        } else {
	            System.out.println("Something went wrong.");
	        }

		
	}

	public static void updatePatient(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void showPatientById(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void deletePatientById(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void showPatients(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

}
