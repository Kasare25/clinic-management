package Operation;

import java.util.Scanner;
import java.util.List;


import Dao.DoctorDAO;
import model.Doctor;

public class DoctorOperation {

	private static final String DoctorID = null;

	public static void addDoctor(Scanner sc) {
		System.out.println("Enter Doctor ID:");
        String DoctorID = sc.next();

        System.out.println("Enter email:");
        String email = sc.next();

        System.out.println("Enter first name:");
        String firstName = sc.nextLine();
        sc.nextLine();

        System.out.println("Enter last name:");                                    
        String lastName = sc.nextLine();

        // Creating object of Doctor class
        Doctor obj = new Doctor(DoctorID, email, firstName, lastName);

        // Calling method to insert into table and passing the object of Instructor class
        boolean result = DoctorDAO.insert(obj);
        if (result) {
            System.out.println("The Doctor is successfully added.");
        } else {
            System.out.println("Something went wrong.");
        }

		
	}

	public static void updateDoctor(Scanner sc) {
		  System.out.println("Enter Doctor ID to update:");
	        String DoctorID = sc.next();

	        System.out.println("Enter email:");
	        String email = sc.next();

	        System.out.println("Enter first name:");
	        String firstName = sc.nextLine();
	        sc.nextLine();

	        System.out.println("Enter last name:");
	        String lastName = sc.nextLine();

	        // Creating object of Doctor class
	        Doctor obj = new Doctor(DoctorID, email, firstName, lastName);

	        // Calling method to update the record in the table
	        boolean result = DoctorDAO.update(obj, DoctorID);
	        if (result) {
	            System.out.println("The Doctor is successfully updated.");
	        } 
	        else {
	            System.out.println("Something went wrong.");
	        }

		
	}

	public static void showDoctorById(Scanner sc) {
		 System.out.println("Enter Doctor ID to get data:");
	        String instructorID = sc.next();
	        Doctor obj = DoctorDAO.getByDoctorID(DoctorID);
	        if (obj != null) {
	            System.out.println(obj);
	        } else {
	            System.out.println("Doctor with ID " + DoctorID + " not found.");
	        }

		
	}

	public static void deleteDoctorById(Scanner sc) {
		 System.out.println("Enter Doctor ID to delete:");
	        String DoctorID = sc.next();

	        // Calling method to delete a particular record
	        boolean result = DoctorDAO.delete(DoctorID);
	        if (result) {
	            System.out.println("The Doctor is successfully deleted.");
	        } else {
	            System.out.println("Something went wrong.");
	        }

		
	}

	public static void showAssignedDiseases(Scanner sc) {
		 List<Doctor> Doctor = DoctorDAO.getAssignedDisease();
	        for (Doctor doctor : Doctor) {
	            System.out.println(Doctor);
	        }

		
	}

	public static void showDoctors(Scanner sc) {
		List<Doctor> Doctors = DoctorDAO.getAllDoctors();
        for (Doctor doctor : Doctors) {
            System.out.println(doctor);
        }
	}
}
		


	
