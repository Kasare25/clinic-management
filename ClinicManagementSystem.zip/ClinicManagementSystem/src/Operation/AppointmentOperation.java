package Operation;

import java.util.Scanner;

public class AppointmentOperation {

	public static void addAppointment(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void updateAppointment(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void showAppointments(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void showAppointmentById(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void deleteAppointmentById(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void showAppointmentByPatientId(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

}
