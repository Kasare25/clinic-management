package Operation;

import java.util.Scanner;

public class MedicalRecordOperation {

	public static void addMedicalRecord(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void updateMedicalRecord(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void showMedicalRecords(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void showMedicalRecordById(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void deleteMedicalRecordById(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	public static void addMedicalRecordByPatientId(Scanner sc) {
		// TODO Auto-generated method stub
		
	}

	

}
