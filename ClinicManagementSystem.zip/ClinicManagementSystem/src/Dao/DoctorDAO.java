package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Connection.ClinicDBConnection;
import model.Doctor;

public class DoctorDAO {
	private static final List<Doctor> Doctor = null;
	static PreparedStatement pstmt = null;
    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;

    // Insert method handles auto-increment
    public static boolean insert(Doctor obj) {
        boolean f = false;
        try {
            conn = ClinicDBConnection.createC();

            String q = "INSERT INTO DOCTOR(DoctorID,DoctorName,Email,DoctorContact) VALUES (?, ?, ?, ?)";
            pstmt = conn.prepareStatement(q);

            pstmt.setString(1, obj.getDoctorID());
            pstmt.setString(2, obj.getDoctorName());
            pstmt.setString(3, obj.getEmail());
            pstmt.setString(4, obj.getDoctorContact());

            pstmt.executeUpdate();

            f = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            closeResources();
        }
        return f;
    }

    // Update Instructor
    public static boolean update(Doctor obj, String DoctorID) {
        boolean f = false;
        try {
            conn = ClinicDBConnection.createC();

            String q = "UPDATE DOCTOR SET Email = ?, DoctorName = ?, DoctorContact = ? WHERE DoctorID = ?";
            pstmt = conn.prepareStatement(q);

            pstmt.setString(1, obj.getDoctorID());
            pstmt.setString(2, obj.getDoctorName());
            pstmt.setString(3, obj.getEmail());
            pstmt.setString(4, obj.getDoctorContact());


            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }

    // Delete Method
    public static boolean delete(String DoctorID) {
        boolean f = false;
        try {
            conn = ClinicDBConnection.createC();

            String qDelete = "DELETE FROM DOCTOR WHERE DoctorID=?";
            pstmt = conn.prepareStatement(qDelete);
            pstmt.setString(1, DoctorID);

            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }

    // Instructor by InstructorID
    public static Doctor getByDoctorID(String DoctorID) {
    	Doctor Doctor = null;
        try {
            conn = ClinicDBConnection.createC();

            String q = "SELECT * FROM DOCTOR WHERE DoctorID=?";
            pstmt = conn.prepareStatement(q);

            pstmt.setString(1, DoctorID);

            rs = pstmt.executeQuery();

            if (rs.next()) {
            	Doctor = new Doctor();
            	Doctor.setDoctorID(rs.getString("DoctorID"));
            	Doctor.setEmail(rs.getString("Email"));
            	Doctor.setDoctorName(rs.getString("DoctorName"));
            	Doctor.setDoctorContact(rs.getString("DoctorContact"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return Doctor;
    }

    public static List<Doctor> getAllDoctors() {
        List<Doctor> Doctors = new ArrayList<>();
        try {
            conn = ClinicDBConnection.createC();

            String q = "SELECT * FROM DOCTOR";
            stmt = conn.createStatement();

            rs = stmt.executeQuery(q);

            while (rs.next()) {
                Doctor Doctor = new Doctor();
                Doctor.setDoctorID(rs.getString("InstructorID"));
                Doctor.setEmail(rs.getString("Email"));
                Doctor.setDoctorName(rs.getString("DoctorName"));
                Doctor.setDoctorContact(rs.getString("DoctorContact"));
                Doctor.add(Doctor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return Doctor;
    }
    
    public static List<Doctor> getAssignedDisease() {
        List<Doctor> Doctor = new ArrayList<>();
        try {
            conn = ClinicDBConnection.createC();

            String q = "SELECT d.DiseaseID, d.DiseaseName " +
                    "FROM Disease d " +
                    "INNER JOIN Appointment a ON d.DiseaseID = d.DiseaseID " +
                    "WHERE e.InstructorID = ?";
            stmt = conn.createStatement();

            rs = stmt.executeQuery(q);

            if (!rs.isBeforeFirst()) {
                System.out.println("No d.Diseases assigned to the Doctor.");
            } else {
                System.out.println("Assigned Disease:");
                while (rs.next()) {
                    String DiseaseID = rs.getString("DiseaseID");
                    String DiseaseName = rs.getString("DiseaseName");
                    System.out.println("DiseaseID: " + DiseaseID + ", DiseaseName: " + DiseaseName );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return Doctor;
    }
    
    // Close resources method
    private static void closeResources() {
        try {
            if (pstmt != null)
                pstmt.close();
            if (rs != null)
                rs.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
