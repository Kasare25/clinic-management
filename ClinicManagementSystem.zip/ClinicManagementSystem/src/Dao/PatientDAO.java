package Dao;

public class PatientDAO {


	public static boolean insert(model.Patient obj) {
		// TODO Auto-generated method stub
		return false;
	}

}
